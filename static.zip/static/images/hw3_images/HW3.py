"""
Name: Brian Palomar
Class: CST205-01_SP22
Date: 3/20/22
Creates GUI that displays a search bar, and combobox.
Once search button is pressed, after the text is 
entered into search bar and image manipulator is picked,
output will be the closest matching picture with these
elements with the picked filter
"""

import sys
from PySide6.QtWidgets import (QApplication, QWidget, QLabel, QPushButton, QLineEdit, 
                                QHBoxLayout, QVBoxLayout, QDialog, QTextBrowser, QComboBox)
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Slot, Qt
from image_info import image_info
from pprint import pprint
from PIL import Image

# Potential searches
string1 = 'cactus near a beach'.lower()
string2 = 'building in Italy'.lower()



""" 
Main window layout
"""

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        # Assignment to layouts
        hbox = QHBoxLayout()
        vbox = QVBoxLayout()
    
        # sets function to be true
        self.button_is_checked = True

        # First Labeller
        self.input = QLineEdit(self)
        self.input.move(20,16)
        self.input.resize(218,40)
        hbox.addWidget(self.input)
        
        # Signals when words are typed into search bar
        self.input.textChanged.connect(self.the_button_is_clicked)

        # stores text into variable
        your_text = self.input.text()

        # Creates search button
        self.btn = QPushButton('Search', self)
        hbox.addWidget(self.btn)
        self.btn.setCheckable(False)
        self.btn.clicked.connect(self.the_button_is_clicked)
        self.btn.setChecked(self.button_is_checked)

        # Connects signal of btn clicked to the filter changer
        self.btn.clicked.connect(self.filter_change)

        # ComboBox
        combobox1 = QComboBox()
        combobox1.addItem('Pick an image manipulation')
        combobox1.addItem('Sepia')
        combobox1.addItem('Negative')
        combobox1.addItem('Grayscale')
        combobox1.addItem('Thumbnail')
        combobox1.addItem('None')

        # Creates variable and connects signals
        self.my_text = None
        combobox1.currentTextChanged.connect(self.combobox_func)
      
        # Sets layout
        vbox.addWidget(combobox1)

        # Sets layout
        mbox = QVBoxLayout()
        mbox.addLayout(hbox)
        mbox.addLayout(vbox)
        self.setLayout(mbox)
        
    @Slot()
    # function for when button is toggled
    
    def the_button_is_clicked(self, checked):
        # Sets btn_is_checked to variable
        self.btn_is_checked = checked
        
        # Assigns user text into 'text'
        text = self.input.text()
        
        # Makes btn clickable
        if(self.btn_is_checked == False):
          # Creates empty dictionary
          new_dict = {}

          """
          Makes info more useful
          """
          def preprocess(my_image_info):
            for i in my_image_info:
              new_dict[i['id']] = [tag.lower() for tag in i['tags']]

              for j in i['title'].split():
                new_dict[i['id']].append(j.rstrip(',').lower())

              new_dict[i['id']].insert(0,0)
              new_dict[i['id']].insert(1, i['title'][0].lower())
              
            return new_dict

          """
          Counter for matches in search to items in image_info
          """
          def get_count_from_search(dictionary, search):
              for key, value in dictionary.items():
                for counter, term in enumerate(value):
                  if counter > 1:
                    if term in search:
                      value[0] += 1
              return dictionary

          preprocess(image_info)
          get_count_from_search(new_dict, text)

          max_list = []
          max_val = 0

          for key, value in new_dict.items():
              for counter, term in enumerate(value):
                if counter == 0:
                  if term >= max_val:
                    if term > max_val and len(max_list) > 0:
                      del max_list[:len(max_list)]
                    max_val = term
                    if max_val > 0:
                      max_list.append((value[1], key))

          max_list.sort()

          # Makes im global
          
          global im
          im = Image.open(f'{max_list[0][1]}.jpg')
          

    
    """
    Makes items in combobox assinable and callable
    """
    def combobox_func(self, text):
      self.my_text = text

    """
    Procedues when certain items are picked in comboboc
    """
    def filter_change(self):
        """
        Sepia filter
        """
        def sepia(p):
          if p[0] < 63:
              r,g,b = int(p[0] * 1.1), p[1], int(p[2] * 0.9)

          elif p[0] > 62 and p[0] < 192:
              r,g,b = int(p[0] * 1.15), p[1], int(p[2] * 0.85)

          else:
              r = int(p[0]* 1.08)
              g,b = p[1], int(p[2] * 0.5)

          return r,g,b
        """
        Puts sepia data into a list
        """
        def sepia_list(pic):
          sepia_list = [sepia(p) for p in pic.getdata()]
          return sepia_list

        # Options for combobox
        if (self.my_text == 'Sepia'):          
          im.putdata(sepia_list(im))
          im.show()

        elif (self.my_text == 'Negative'):
          negative_list = [((a[0]*299 + a[1]*587 + a[2]*144)// 1000,) * 3
                            for a in im.getdata() ]

          im.putdata(negative_list)
          im.show()

        elif (self.my_text == 'Grayscale'):
          gray_list = [ ( (a[0]+a[1]+a[2])//3, ) * 3
                            for a in im.getdata() ]
          im.putdata(gray_list)
          im.show()

        elif (self.my_text == 'Thumbnail'):
          im1 = im.resize((400,400), resample=0)
          im1.show()

        elif (self.my_text == 'None'):
          im.show()

        else:
          print("Please pick an image manipulator!")

      


app = QApplication(sys.argv)
mainWin = MainWindow()
mainWin.show()
app.exec()

